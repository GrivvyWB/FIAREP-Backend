FIAREP COMPLETE WEBSITE
========================
This is a static, responsive website prototype with connected navigation.

PUBLIC:
index.html, inspections.html, estimates.html, repairs.html, projects.html, reports.html,
calendar.html, clients.html, team.html, settings.html, about.html, contact.html

APP:
dashboard.html plus the same navigation tabs, new-inspection.html and upload-report.html.

AUTH:
login.html and signup.html use browser localStorage for DEMO authentication only.
This is not production authentication. Replace with your real auth/backend before launch.

To run:
1. Upload all files to your web host or Replit.
2. Keep all files in the same directory.
3. Open index.html.
4. Click Get Started / Login to enter the demo dashboard.
5. Use the sidebar to navigate between connected pages.
