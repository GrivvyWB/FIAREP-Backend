
const navItems=[
 ["Dashboard","dashboard.html","▦"],["Inspections","inspections.html","⌕"],["Estimates","estimates.html","▤"],
 ["Repairs","repairs.html","⚒"],["Projects","projects.html","▣"],["Reports","reports.html","▧"],
 ["Calendar","calendar.html","◷"],["Clients","clients.html","♧"],["Team","team.html","♙"],["Settings","settings.html","⚙"]
];
function buildSidebar(){
 const el=document.querySelector("#sidebar"); if(!el)return;
 const current=location.pathname.split("/").pop()||"dashboard.html";
 el.innerHTML=`<div class="sidebrand"><span class="mark">F</span><div><b>FIAREP</b><small>FIELD INSPECTION & REPAIR ESTIMATION</small></div></div>
 <div class="side">${navItems.map(x=>`<a class="${current===x[1]?"active":""}" href="${x[1]}"><span>${x[2]}</span>${x[0]}</a>`).join("")}</div>
 <div class="quick"><div style="font-size:11px;color:#9aa7ad;margin-bottom:7px">QUICK ACTION</div><a class="btn primary" href="new-inspection.html">＋ New Inspection</a><a class="btn outline" href="upload-report.html">↥ Upload Report</a></div>
 <button class="logout" onclick="logout()">⇥ Sign out</button>
 <div style="font-size:10px;color:#687780;padding:10px">© 2026 FIAREP<br>All rights reserved.</div>`;
}
function authGuard(){
 if(!document.body.classList.contains("appbody"))return;
 if(localStorage.getItem("fiarepAuth")!=="1"){location.href="login.html";return}
 const user=localStorage.getItem("fiarepUser")||"John Smith";
 const nameEls=document.querySelectorAll("[data-user]");
 nameEls.forEach(e=>e.textContent=user);
}
function logout(){localStorage.removeItem("fiarepAuth");location.href="index.html"}
function setupMobile(){
 const b=document.querySelector("#menuBtn"), s=document.querySelector("#sidebar");
 if(b&&s)b.onclick=()=>s.classList.toggle("open");
}
function loginForm(){
 const f=document.querySelector("#loginForm"); if(!f)return;
 f.addEventListener("submit",e=>{e.preventDefault();const email=document.querySelector("#email").value.trim();const name=document.querySelector("#name")?.value.trim()||"John Smith";if(!email){document.querySelector("#msg").textContent="Enter your email.";return}localStorage.setItem("fiarepAuth","1");localStorage.setItem("fiarepUser",name);location.href="dashboard.html"});
}
function signupForm(){
 const f=document.querySelector("#signupForm"); if(!f)return;
 f.addEventListener("submit",e=>{e.preventDefault();const n=document.querySelector("#name").value.trim();const email=document.querySelector("#email").value.trim();if(!n||!email){document.querySelector("#msg").textContent="Please complete the required fields.";return}localStorage.setItem("fiarepAuth","1");localStorage.setItem("fiarepUser",n);location.href="dashboard.html"});
}
document.addEventListener("DOMContentLoaded",()=>{buildSidebar();authGuard();setupMobile();loginForm();signupForm()});
