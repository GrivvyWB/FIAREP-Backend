# FIAREP — Session Handoff (current)

Paste this at the start of a new chat to continue with full context.

---

## WHAT FIAREP IS
Field Repair and Estimation Platform — a React Native / Expo SDK 54 iOS app for
building repair inspection, scoping, procurement, worker/vendor/emergency dispatch,
AI-assisted inspection, and employee leave management. Solo dev (Tim), Grivvy Com
LLC. Local-first (SQLite via lib/store.ts); no backend wired yet. Separate static
marketing website too (see bottom).

## ENVIRONMENT
- iOS repo: `~/Desktop/consruction/construction-pm` ("consruction" misspelled on
  disk — correct). Branch `main`. Bundle `com.tmstni.construction-pm`. iPhone 15
  Pro Max. Accent `#185FA5`. Local SQLite `construction.db`.
- Website: `~/Desktop/fiarep/FIAREP_Complete_Website/` — static HTML/CSS/JS, yellow
  accent (`--yellow:#ffd21a`), Inter font, sidebar app shell via app.js (localStorage
  auth). Pages share styles.css. leave.html added this session.
- Backend (not wired): `ssh -i ~/.ssh/fiarep.pem ubuntu@18.219.209.89`,
  `~/fiarep-api`, Express 5 + Drizzle + RDS Postgres, branch `master`.

## STANDING WORK RULES (STRICT)
- Deliver patches as heredoc **Python installers** Tim runs himself (assistant's
  shell can't reach his Mac). Give commands; he pastes output.
- Large/new files: present_files → download → verify `shasum -a 256` → move into
  place → `npx tsc --noEmit && echo TYPECHECK_CLEAN`.
- One edit per command. Typecheck before every commit. Commit per change.
- When about to give code, STOP talking and put the code in its own message.
- Don't ask which item to do next on a list — go down it. Be terse.
- Do NOT move the assign/approve section at the bottom of `app/project/[id].tsx`.
- Never ask Tim to paste passwords or API keys into chat.
- zsh gotchas: quote bracket paths; `!` in grep triggers history expansion; a
  grep with `<Text style={ui.h}>` can leave a stuck `dquote>` prompt (Ctrl+C);
  /tmp heredocs sometimes don't persist — re-send. Write the actual ▾ char in JSX
  (NOT the \u25be escape). A patch anchor that splits a function nests/breaks it —
  verify scope after. "anchor: 0" on re-run usually means the FIRST run already
  applied it — grep to confirm before assuming failure.

## ARCHITECTURE
- `lib/store.ts` = the single data seam. ~30+ SQLite tables as (id, state-JSON),
  hundreds of exported functions. Each maps to a future API endpoint.
- Roles (StaffRole): administrator, management, worker, inspector, procurement,
  vendor, resident, **emergency** (no-login mode for trucks).
- getCurrentPosition() drives per-position gating. An account's position is whatever
  it was ISSUED as (a worker issued as "Staff Worker" resolves to that even if you
  meant inspector). Violation-alert buttons fetch position at tap time and fall back
  to showing worker/inspector buttons.
- NOTHING is emailed anywhere — every notification is an in-app inbox record
  (addNotification → notifications table → Inbox). Confirmed by grep: no SMTP/mail
  code. Leave requests/approvals are in-app only.

## MAJOR SYSTEMS
- **Inspection chain:** mgmt sends violation → inspector logs → **Approve & route**:
  Send to a tradesman (route picker, trades) OR Send to a CPM (picker shows CPMs →
  scopes → back to mgmt → procurement). Route picker collapsible by position.
- **FIAREP VISION (AI):** Job Details / violation notification → FIAREP Vision →
  photo → GPT-4o (lib/aiVision.ts) → A/B/C + confidence + HPD code + trade + priority
  + observation → Accept saves a BuildingViolation WITH photo. Mgmt sees the photo in
  Inspection Approvals. Anyone sent a complaint (workers + inspectors). Key in
  lib/aiConfig.ts (GITIGNORED; move to backend proxy before release).
- **EMERGENCY UNITS:** admin/Borough Director/Regional Director register trucks
  (Manage Trucks → TRK-#### code), Assign Emergency Unit (dropdown + dev-scoped
  address + location + issue → EM- id), Truck Scores. Trucks: role picker → 🚨
  Emergency Unit (no login) → enter CODE → jobs → progress/photos/complete +
  persistent banner + 20s repeating alert. Mgmt/supervisors: read-only Emergency
  Activity. No emergency inbox notifications.
- **LEAVE MANAGEMENT (app + website):** Request Time Off (worker for self / mgmt for
  anyone): employee autocomplete → autofills title/dev/supervisor; scroll date
  pickers (year +30); "Amount of time" picker (Full day, Quarter/Half/Three-quarter
  day, 1/3/5/7h); live balances (annual allotments, 8h=1day); 9 types. **My Requests**
  button shows the person's own requests with status badges. Leave Calendar dashboard:
  month grid (today highlighted, leave color-coded approved-solid/pending-faded, US
  holidays ★ incl. Election Day, tap a day for who's out), filterable list,
  Approve/Deny, overlap conflict alerts. **Borough Director sees ONLY management-tier
  leave** (Borough/Regional Dir, Property Mgr, Asst PM, Superintendent, Asst Super).
  Website leave.html mirrors it (localStorage demo data).
- **Change work orders** (CPM cost + worker no-cost), **Elevator Service** (EL- ids,
  supervisor dashboard), two repair tracks — all intact.

## ROLE GATING & HIERARCHY
- Position order (top→down): **Borough Director**, Regional Director, Property Manager,
  Assistant Property Manager, Superintendent, Assistant Superintendent, Housing
  Assistant, Maintenance Worker, Caretaker, Groundskeeper, Janitorial Staff, CPM,
  Inspector, Elevator Service, Plumber, Electrician, Carpenter, Roofer, General
  Construction, CCTV Installation, Heating Service, Staff Worker, Director, Other.
- Admin-home header bar shows the person's TITLE (Borough Director, etc.) via
  navigation.setOptions, else 'Administrator'.
- Workers/inspectors/elevator mechs: NO pricing. General Construction = vendor.
- Supervisors (position ends "Supervisor"/Superintendent): Staff Member login →
  Management section, header shows title.
- **F (red-items):** ELEVATED (all modules): administrator, Regional Director, Borough
  Director, Superintendent, plain management. RESTRICTED supervisors limited; admin
  modules hidden; empty sections don't render.
- **Emergency admin** = admin/Borough Director/Regional Director ONLY.
- **Regional Director** (mgmt account) issues/deletes everyone except administrators.
- **DELETE / TWO-STAGE:** workers can't delete anything UNLESS management clears the
  job first. "Clear for staff" (Inspection Approvals) + "Clear for worker" (Resident
  Reports on resolved assigned jobs) set clearedByMgmt → worker's "Remove (cleared by
  management)" button appears in My Jobs. Only management/admin delete notifications.

## COLLAPSIBLE / CLOSE-BUTTON UI (to prevent flooding)
- Collapsible sections (tap header + count) on: Manage Requests, Scope Approvals,
  Change Orders (Needs action / History), Resident Reports (collapsible Reports list),
  Procurement (already had them).
- Close buttons on dropdown screens: Development Scores, Truck Scores, Audit Log,
  Resident Reports (dev filter reset).

## HOME-SCREEN ALERT BANNER
- `components/AlertBanner.tsx`: a red banner that PULSES (Animated opacity loop)
  when unread alerts > 0, tappable → opens /notifications. Shows "X new alerts —
  tap to view". Placed at the top of the management, admin, CPM/Inspector, and
  worker home screens (each already tracks an `unread` count via unreadCount).
- On-device only. Cross-device alerts and the PC/website blink need the backend
  (push + sync) — not possible until it's wired.

## NOTIFICATIONS / ALERTS
WORKING NOW (Expo Go / current build):
- Blinking AlertBanner on management/admin/CPM/worker homes (pulses when unread>0,
  taps to Inbox).
- Phone VIBRATES on a new alert (count rises) — built-in RN Vibration, no native dep.

DORMANT — native modules installed but NOT loadable in Expo Go, so they are wired to
lazy-load / not run until a DEVELOPMENT BUILD (npx expo run:ios or EAS):
- Chime sound: assets/alert.wav via expo-av. AlertBanner lazy-requires expo-av inside
  playChime (require in try/catch) so Expo Go doesn't crash; plays only when the
  native module is present.
- lib/push.ts (expo-notifications + expo-device): requestNotificationPermission(),
  registerForPush() (Expo push token), notifyLocal(). All lazy-require the native
  modules and no-op if absent. IMPORTANT: _layout.tsx no longer calls push on launch
  (calling it crashed Expo Go with "Cannot find native module ExpoPushTokenManager").
  Re-add the launch permission call ONLY after a dev build exists.

CRITICAL LESSON: native modules (expo-av, expo-notifications, expo-device) CANNOT
load in Expo Go — importing them at module scope crashes the whole app on load. Order
must be: install → make a development build → THEN wire them in. They are currently
dormant/guarded so the app runs.

STILL NEEDS BACKEND: alerts when the app is closed/backgrounded, cross-device, and on
the PC/website all require a server to send remote pushes to the registered tokens.

## C — MULTI-DEVELOPMENT ACCESS
- Development multi-picker shows for ALL staff at issue; saves developments[].
  My Jobs filters resident jobs to the worker's developments (LENIENT).

## CODES
RC-##### resident complaint · sr-##### procurement · EL-##### elevator · EM-#####
emergency · TRK-#### truck · 4-char staff login. Violation numbers are manual.

## REMAINING (see FIAREP-REMAINING.md)
- Leave reports + exports (history, staffing impact, monthly absence, upcoming,
  overtime risk → PDF/Excel/CSV).
- Phase A: thread resident data further downstream; Phase C: procurement payout stages.
- Classify new NYCHA titles for price/screen gating.
- Housekeeping: wipe test data; remove lib/photos.ts.bak.1786739646.
- Move OpenAI key to backend proxy before release.

## THE BACKEND (separate project — #1 gap for a real pilot)
Wire lib/store.ts to the API; cross-device sync (nothing syncs today); APNs push;
S3 for photos; server-side role enforcement; OpenAI proxy for FIAREP Vision. App AND
website converge on the same data once wired (website leave.html uses localStorage
demo data until then).

## FILES ADDED (across sessions)
app/: dev-scores, inspection-approvals, my-jobs, cpm-change-order, worker-change-order,
elevator-dashboard, assign-emergency, emergency-units, emergency-activity,
manage-trucks, truck-scores, fiarep-vision, leave-request, leave-dashboard.
components/AddressInput, components/AlertBanner. lib/: push, aiConfig (gitignored), aiVision, scopeExcel. assets/alert.wav. Existing lib/: aiConfig (gitignored), aiVision, scopeExcel. Website:
leave.html. Docs (outputs): FIAREP-Session-Summary, FIAREP-Capabilities, FIAREP-Codes,
FIAREP-Overview, FIAREP-TODO, FIAREP-REMAINING, BACKEND-WIRING-SPEC, FIAREP-HANDOFF.
