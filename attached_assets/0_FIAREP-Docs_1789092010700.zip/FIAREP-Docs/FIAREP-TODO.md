# FIAREP — Build Checklist

Working list so we knock these down one at a time. Check off as we go.

---

## PHASE A — Resident complaint data carries through the whole chain (pre-fill everywhere)
Goal: a complaint (anonymous, partial, or full) is ALWAYS pre-filled for every role:
Management → Inspector → CPM → Worker → Procurement. No re-entry.

- [x] ResidentReport: generate `RC-XXXXX` complaint number
- [x] ResidentReport: carry residentName + contact + development
- [x] ViolationLookup: carry complaintNo / residentName / contact / development
- [x] sendViolationLookup: accept + store resident data
- [x] report-detail: show Complaint #, Resident (or Anonymous), Contact
- [x] BuildingViolation: fields to carry complaintNo / residentName / contact
- [x] Send Violation screen: accept pre-fill params + pass resident data to the lookup
- [ ] **report-detail: add "Send to Inspector" button (mgmt/admin) → opens Send Violation pre-filled**  ← NEXT
- [ ] Support location-only complaints (Hallway, Lobby, Stairwell, Basement) + anonymous (address only)
- [ ] Inspector logs violation: carry resident data from the lookup onto the BuildingViolation
- [ ] Inspector Log Violations: show/pre-fill complaint # + resident (read-only context)
- [ ] Repair-complaint fast path: management assigns straight to worker/plumber (skip inspector) with pre-fill
- [ ] No-Heat path: system requires an inspector (mandatory), auto-routes
- [ ] CPM scope: pre-fill + display complaint # / resident / unit / location / violation details
- [ ] Vendor quote: carry the same complaint context (read-only)
- [ ] Worker My Jobs: show complaint # / resident / location on the job
- [ ] Procurement: show the full pre-filled package (scope, violation, resident, notes, orders)
- [ ] Photos carry through each hop (complaint photo visible downstream)

## PHASE B — Emergency Work-Order button
- [ ] Emergency flag on a job (must complete today / next day)
- [ ] Emergency notes become mandatory when flagged
- [ ] Emergency flag follows the job through CPM, workers, procurement (visible everywhere)
- [ ] Emergency jobs sort/flag to top of lists

## PHASE C — Procurement vendor payout stages
- [ ] Payout buttons: 15% / 20% / 30% / Final completion
- [ ] Procurement selects payout stage by job progress
- [ ] Payout history shown on the job

## PHASE D — Multi-development access control (BIG, last)
- [ ] Every record reliably carries a development (scopes, violations, reports, routes)
- [ ] City Code + Borough Code + Development Code on each development
- [ ] Managers/Supervisors see ONLY their own development by default (complaints, violations, scopes, procurement, work orders)
- [ ] Development dropdown to switch view
- [ ] CPMs see only scopes for their development
- [ ] Commissioner/Administrator sees all developments
- [ ] Clear Access button: request City/Borough/Development → Commissioner approves/denies → grant (temp or permanent) → audit-logged
- [ ] Access can be revoked anytime
- [ ] All access changes logged for audit

## TWO-STAGE DELETE (management clears → staff can then delete)
- [x] Inspection chain (building violations): clearedByMgmt flag, mgmt "Clear for staff", My Jobs gated delete
- [ ] Replicate to scopes
- [ ] Replicate to resident reports
- [ ] Replicate to routes

## HOUSEKEEPING / KNOWN ISSUES
- [ ] Wipe test data (duplicate scopes inflating dev scores)
- [ ] Regenerate BACKEND-WIRING-SPEC to include vendor_quotes, project_scopes, walkthrough fields, dev-scoring, inspection chain
- [ ] Reconcile branches (iOS main vs backend master); regenerate Drizzle journal
- [ ] Remove stray file lib/photos.ts.bak.1786739646
- [ ] Optional: normalize addresses in dev-scoring (same address typed differently = separate buckets)
- [ ] Audit log: extend logging to scope-submit + other flows if wanted

## BACKEND (the big separate project — after the above)
- [ ] Wire lib/store.ts functions to the API (the single seam)
- [ ] Cross-device sync (nothing syncs today)
- [ ] APNs push notifications
- [ ] S3 for photos/scans/scope files
- [ ] Session invalidation on role/tier change
- [ ] City violation lookup via NYC Open Data
