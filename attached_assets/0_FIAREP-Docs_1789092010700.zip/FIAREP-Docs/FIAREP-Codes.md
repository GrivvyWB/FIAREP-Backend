# FIAREP — System Codes Reference

Every code the platform generates. Each prefix is distinct so you can tell at a
glance what kind of record you're looking at.

| Code | Format | Identifies | Created when |
|------|--------|-----------|--------------|
| **RC-#####** | RC- + 5 digits | Resident Complaint number | A resident/management files a complaint |
| **sr-#####** | sr- + 5 digits | Procurement tracking ID (vendor job) | Procurement broadcasts a scope to vendors |
| **EL-#####** | EL- + 5 digits | Elevator Job ID | An elevator job is assigned to a mechanic |
| **EM-#####** | EM- + 5 digits | Emergency Job ID | An emergency is dispatched to a truck |
| **TRK-####** | TRK- + 4 digits | Truck / Emergency Unit code | Admin/director registers a truck |
| **Staff login code** | 4 characters (e.g. K7P3) | A staff member's login credential | An account is issued or reset |

## Notes
- Staff login codes use an unambiguous character set:
  `ABCDEFGHJKLMNPQRSTUVWXYZ23456789` (no 0, O, 1, or I) so they're easy to read
  aloud without confusion.
- **Violation numbers are NOT auto-generated** — the inspector/management types the
  actual HPD/DOB violation number manually.
- Internal record IDs (timestamp + random string) exist on every record but are not
  user-facing codes.

## Quick reference
- RC = Resident Complaint
- sr = Procurement / vendor job (service request)
- EL = Elevator job
- EM = Emergency job
- TRK = Truck (emergency unit)
- 4-char code = Staff login
