import ExpoModulesCore
import ARKit

public class ARMeasureModule: Module {
  private var delegate: ARMeasureDelegate?
  public func definition() -> ModuleDefinition {
    Name("ARMeasure")
    Function("isSupported") { () -> Bool in
      return ARWorldTrackingConfiguration.isSupported
    }
    AsyncFunction("measure") { (promise: Promise) in
      guard ARWorldTrackingConfiguration.isSupported else {
        promise.reject("UNSUPPORTED", "AR measuring requires an ARKit-capable device.")
        return
      }
      DispatchQueue.main.async {
        let d = ARMeasureDelegate(promise: promise)
        self.delegate = d
        d.present()
      }
    }
  }
}
