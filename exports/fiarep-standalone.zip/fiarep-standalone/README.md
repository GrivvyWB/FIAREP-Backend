# FIAREP Standalone Mobile Source

This package contains the FIAREP Expo mobile app and its generated API client.

## Requirements

- Node.js 22 or newer
- pnpm 10.26.1
- A running FIAREP API server reachable over HTTPS

## Install

```bash
pnpm install
```

## Configure and run

Set `EXPO_PUBLIC_DOMAIN` to the API host without `https://`, then start Expo:

```bash
EXPO_PUBLIC_DOMAIN=your-api.example.com pnpm --filter @workspace/fiarep-mobile exec expo start
```

The app expects FIAREP API routes on that host. Secrets and backend source are not included.

## Verify

```bash
pnpm run typecheck
```
